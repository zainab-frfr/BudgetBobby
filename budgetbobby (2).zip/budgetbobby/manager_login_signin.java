package budgetbobby;

import jdk.jfr.events.FileWriteEvent;

import java.io.FileWriter;
import java.io.IOException;

public class manager_login_signin {


    UserAccounts accounts;

    public manager_login_signin(UserAccounts accounts) {
        this.accounts = accounts;
    }

    public boolean checkIfUserExitsID(int ID){
        return accounts.findUser(ID) != null;
    }
    public boolean checkIfUserExitsEmail(String email){
        return accounts.allUsers.findUserEmail(email);
    }

    //login methods
    public void login(int ID){
        boolean isPresent = checkIfUserExitsID(ID);
        if(!isPresent){
            System.out.println("ID doesn't exist");
            //go to sign up page
            //signUp(ID);
        }

    }
    //signup methods

    //id will be generated in manager and that will be sent here from the file by one increment in the counter
    public void signUp(String userName, String email, String area, int calories,int ID){

        boolean isPresent = checkIfUserExitsEmail(email);
        if(isPresent){
            System.out.println("You already have an account");
            //go to login page
            //login(ID);
        }
        else{
            User toAdd = new User(userName,email,area,calories,ID);
            accounts.addUser(toAdd);

        }
    }

    public void writingUser() throws IOException {

        String usersPath = "C:\\Users\\SAR Computers\\BudgetBobby\\Users.txt";
        FileWriter fileWriter = new FileWriter(usersPath);
        
    }

}
