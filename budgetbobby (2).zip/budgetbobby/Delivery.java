/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package budgetbobby;

/**
 *
 * @author zaina
 */
public class Delivery {
    //graph storing areas and distances
    String restaurantArea;
    String userArea;
    //priority queue of orders placed
    User user;
    
    
    //shortest distance calculation method
    
    // email sending and confirmation process
    
    
}
