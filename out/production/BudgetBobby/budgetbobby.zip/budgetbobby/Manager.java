/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package budgetbobby;

import budgetbobby.DataStructures.LinkedList;

/**
 *
 * @author zaina
 */
public class Manager {
    // Hashmap of restaurant
    UserAccounts accounts;
    Delivery delivery;
    LinkedList<Restaurant> allRestaurants = new LinkedList<>();

    //method for reading restaurants and creating restaurants in list

    //method for reading existing users and storing them in list

    //method to input user selection

    
    // filter display
}
